package com.tasfb2b.service;

import com.tasfb2b.dto.ShipmentCreateDto;
import com.tasfb2b.model.Airport;
import com.tasfb2b.model.Shipment;
import com.tasfb2b.model.ShipmentAuditType;
import com.tasfb2b.model.ShipmentStatus;
import com.tasfb2b.model.SimulationConfig;
import com.tasfb2b.model.TravelStop;
import com.tasfb2b.repository.AirportRepository;
import com.tasfb2b.repository.ShipmentRepository;
import com.tasfb2b.repository.SimulationConfigRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ShipmentOrchestratorService {

    private final AirportRepository airportRepository;
    private final ShipmentRepository shipmentRepository;
    private final SimulationConfigRepository simulationConfigRepository;
    private final RoutePlannerService routePlannerService;
    private final ShipmentAuditService shipmentAuditService;
    private final ShipmentCodeService shipmentCodeService;
    private final SimulationRuntimeService simulationRuntimeService;

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public Shipment createAndPlan(ShipmentCreateDto dto) {
        Airport origin = airportRepository.findByIcaoCode(dto.originIcao().trim().toUpperCase())
                .orElseThrow(() -> new IllegalArgumentException("Aeropuerto origen no encontrado: " + dto.originIcao()));
        Airport destination = airportRepository.findByIcaoCode(dto.destinationIcao().trim().toUpperCase())
                .orElseThrow(() -> new IllegalArgumentException("Aeropuerto destino no encontrado: " + dto.destinationIcao()));

        if (origin.getId().equals(destination.getId())) {
            throw new IllegalArgumentException("El origen y destino no pueden ser iguales");
        }

        int requested = dto.luggageCount();
        int projectedLoad = origin.getCurrentStorageLoad() + requested;
        if (projectedLoad > origin.getMaxStorageCapacity()) {
            throw new IllegalArgumentException("Capacidad maxima del nodo excedida");
        }

        LocalDateTime registrationDate = dto.registrationDate() == null
                ? simulationRuntimeService.currentSimulationTime().orElse(LocalDateTime.now())
                : dto.registrationDate();

        Shipment shipment = Shipment.builder()
                .shipmentCode(shipmentCodeService.nextCode(registrationDate))
                .airlineName(dto.airlineName().trim())
                .originAirport(origin)
                .destinationAirport(destination)
                .luggageCount(requested)
                .registrationDate(registrationDate)
                .status(ShipmentStatus.PENDING)
                .progressPercentage(0.0)
                // Registro manual = operación EN VIVO (DAY_TO_DAY). El import del dataset queda HISTORICAL (default).
                .source(com.tasfb2b.model.ShipmentSource.LIVE)
                .build();

        shipmentRepository.save(shipment);

        shipmentAuditService.log(
                shipment,
                ShipmentAuditType.CREATED,
                "Envio creado y en espera de planificacion",
                origin,
                null
        );

        String algorithmName = dto.algorithmName() == null
                ? activeAlgorithmName()
                : dto.algorithmName();
        List<TravelStop> plannedStops = routePlannerService.planShipment(shipment, algorithmName);
        if (plannedStops.isEmpty()) {
            shipment.setStatus(ShipmentStatus.CRITICAL);
            shipmentRepository.save(shipment);
        }
        return shipment;
    }

    @Transactional(readOnly = true)
    public com.tasfb2b.dto.ShipmentFeasibilityDto checkFeasibility(ShipmentCreateDto dto) {
        Airport origin = airportRepository.findByIcaoCode(dto.originIcao().trim().toUpperCase())
                .orElseThrow(() -> new IllegalArgumentException("Aeropuerto origen no encontrado: " + dto.originIcao()));
        Airport destination = airportRepository.findByIcaoCode(dto.destinationIcao().trim().toUpperCase())
                .orElseThrow(() -> new IllegalArgumentException("Aeropuerto destino no encontrado: " + dto.destinationIcao()));

        if (origin.getId().equals(destination.getId())) {
            throw new IllegalArgumentException("El origen y destino no pueden ser iguales");
        }

        int requested = dto.luggageCount();
        int projectedLoad = origin.getCurrentStorageLoad() + requested;
        if (projectedLoad > origin.getMaxStorageCapacity()) {
            throw new IllegalArgumentException("Capacidad maxima del nodo excedida");
        }

        Shipment shadow = Shipment.builder()
                .shipmentCode("SHADOW")
                .airlineName(dto.airlineName().trim())
                .originAirport(origin)
                .destinationAirport(destination)
                .luggageCount(requested)
                .registrationDate(dto.registrationDate() == null
                        ? simulationRuntimeService.currentSimulationTime().orElse(LocalDateTime.now())
                        : dto.registrationDate())
                .status(ShipmentStatus.PENDING)
                .progressPercentage(0.0)
                .isInterContinental(origin.getContinent() != destination.getContinent())
                .build();
        shadow.setDeadline(shadow.getRegistrationDate().plusDays(Boolean.TRUE.equals(shadow.getIsInterContinental()) ? 2 : 1));

        String algorithm = dto.algorithmName() == null ? activeAlgorithmName() : dto.algorithmName();
        List<TravelStop> stops = routePlannerService.previewRoute(shadow, algorithm);
        boolean feasible = !stops.isEmpty();

        String message = feasible
                ? "Ruta factible dentro de la red actual."
                : "No se encontro ruta que cumpla plazo/capacidad con la red actual.";

        return new com.tasfb2b.dto.ShipmentFeasibilityDto(feasible, message, algorithm, stops.size());
    }

    private String activeAlgorithmName() {
        SimulationConfig config = simulationConfigRepository.findLiveConfigOrFirst();
        if (config == null) {
            return "Genetic Algorithm";
        }
        String primary = config.getPrimaryAlgorithm().name();
        if ("ANT_COLONY".equals(primary)) return "Ant Colony Optimization";
        if ("SIMULATED_ANNEALING".equals(primary)) return "Simulated Annealing";
        return "Genetic Algorithm";
    }

}
